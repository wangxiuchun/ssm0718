package com.aaa.dao;

import java.util.List;
import java.util.Map;

public interface StuDao {
    //1.不用考虑两个表之间的到底是一对多还是多对一
    //2.不用考虑实体类的属性是否和数据库列名是否一致
    public List<Map> selectStu();
    public int addStu(Map map);
    public void deleteStu(int stuid);
    public void modifyStu(int stuid);
}
