package com.aaa.service;

import java.util.List;
import java.util.Map;

public interface StuService {
    public List<Map> selectStu();

    public int addStu(Map map);

    public void deleteStu(int id);

    public void modifyStu(int id);
}
